package br.com.healthtrack;

/* A classe ContaFree herda os atributos da classe Usuario
 */
public class ContaFree extends Usuario {

}
