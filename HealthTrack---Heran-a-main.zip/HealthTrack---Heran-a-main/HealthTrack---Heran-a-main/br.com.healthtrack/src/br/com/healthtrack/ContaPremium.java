package br.com.healthtrack;

/* A classe ContaPremium armazena as informa��es de n�mero do cart�o e pin do Cart�o, sendo uma classe filha da classe Usuario herda os atributos da classe
 */
public class ContaPremium extends Usuario{
	protected int nrCartao;
	protected int pinCartao;
	
	public int getNrCartao() {
		return nrCartao;
	}
	public void setNrCartao(int nrCartao) {
		this.nrCartao = nrCartao;
	}
	public int getPinCartao() {
		return pinCartao;
	}
	public void setPinCartao(int pinCartao) {
		this.pinCartao = pinCartao;
	}

}
