module br.com.healthtrack {
	requires java.desktop;
}